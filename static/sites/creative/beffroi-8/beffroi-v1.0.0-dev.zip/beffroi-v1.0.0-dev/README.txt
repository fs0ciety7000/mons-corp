Beffroi 1.0.0-dev — famille de polices pixel de CARDOR Media

Réservé aux productions CARDOR Media.

Contenu :
  fonts/ttf, fonts/otf, fonts/woff2   polices vectorielles (pixels carrés, sans hinting)
  fonts/css/beffroi.css               @font-face (woff2 puis ttf)
  bitmap/<slug>.png|fnt|xml|json      bitmap fonts BMFont (Phaser 3 : .xml)
  manifest.json                       métriques, fichiers et glyphes

Styles (taille nette = multiple de la grille, en px CSS) :
  Beffroi8-Regular         grille 8 px
  Beffroi8-Bold            grille 8 px
  Beffroi16-Display        grille 16 px
  Beffroi5-Mini            grille 5 px
